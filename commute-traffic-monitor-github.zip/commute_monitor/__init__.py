"""Morning commute traffic monitor."""
