from __future__ import annotations

import argparse
import logging

from .config import Settings
from .monitor import run_morning, run_once


def main() -> None:
    parser = argparse.ArgumentParser(description="Monitor de tráfico del trayecto al trabajo")
    parser.add_argument("--once", action="store_true", help="Hace una medición inmediata y termina")
    parser.add_argument("--send", action="store_true", help="Con --once, también envía correo")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    settings = Settings.from_env()
    if args.once:
        run_once(settings, send=args.send)
    else:
        run_morning(settings)


if __name__ == "__main__":
    main()
