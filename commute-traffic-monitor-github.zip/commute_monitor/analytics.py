from __future__ import annotations

from dataclasses import dataclass

from .models import TrafficSample


@dataclass(frozen=True)
class TrendResult:
    slope_minutes_per_10: float
    label: str


@dataclass(frozen=True)
class ForecastResult:
    target_time: str
    estimated_minutes: float
    method: str


def hhmm_to_minutes(value: str) -> int:
    hour, minute = [int(x) for x in value.split(":", 1)]
    return hour * 60 + minute


def linear_fit(samples: list[TrafficSample]) -> tuple[float, float]:
    """Return slope/minute and intercept for y=duration_minutes vs scheduled clock minute."""
    if not samples:
        raise ValueError("Se necesita al menos una muestra")
    if len(samples) == 1:
        return 0.0, samples[0].duration_minutes

    xs = [float(hhmm_to_minutes(s.scheduled_time)) for s in samples]
    ys = [s.duration_minutes for s in samples]
    x_bar = sum(xs) / len(xs)
    y_bar = sum(ys) / len(ys)
    denom = sum((x - x_bar) ** 2 for x in xs)
    if denom == 0:
        return 0.0, y_bar
    slope = sum((x - x_bar) * (y - y_bar) for x, y in zip(xs, ys)) / denom
    intercept = y_bar - slope * x_bar
    return slope, intercept


def gradient(
    samples: list[TrafficSample],
    moderate_threshold: float,
    fast_threshold: float,
    extreme_threshold: float,
) -> TrendResult:
    if len(samples) < 2:
        return TrendResult(0.0, "estable")
    recent = samples[-3:]
    slope_per_minute, _ = linear_fit(recent)
    slope_per_10 = slope_per_minute * 10.0
    if slope_per_10 <= moderate_threshold:
        label = "estable"
    elif slope_per_10 <= fast_threshold:
        label = "creciente moderado"
    elif slope_per_10 <= extreme_threshold:
        label = "creciente rápido"
    else:
        label = "creciente extremo"
    return TrendResult(slope_per_10, label)


def forecast_for_target(samples: list[TrafficSample], target_time: str) -> ForecastResult:
    if not samples:
        raise ValueError("No hay muestras para estimar")
    target_minute = hhmm_to_minutes(target_time)

    # Once the exact target sample exists, that observed value becomes the best
    # estimate for 07:00 and is kept in later emails.
    exact = [s for s in samples if hhmm_to_minutes(s.scheduled_time) == target_minute]
    if exact:
        return ForecastResult(target_time, exact[-1].duration_minutes, "observado a la hora objetivo")

    usable = [s for s in samples if hhmm_to_minutes(s.scheduled_time) < target_minute]
    if len(usable) >= 2:
        slope, intercept = linear_fit(usable)
        estimate = slope * target_minute + intercept
        # Avoid impossible extrapolations caused by noisy measurements.
        floor = min(s.duration_minutes for s in usable) * 0.75
        ceiling = max(s.duration_minutes for s in usable) * 1.75
        estimate = max(floor, min(estimate, ceiling))
        return ForecastResult(target_time, estimate, f"regresión lineal con {len(usable)} catas")

    return ForecastResult(target_time, samples[-1].duration_minutes, "última cata disponible")
