from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _float(name: str, default: float) -> float:
    value = os.getenv(name)
    return default if value is None else float(value)


def _int(name: str, default: int) -> int:
    value = os.getenv(name)
    return default if value is None else int(value)


@dataclass(frozen=True)
class Settings:
    tomtom_api_key: str
    origin_address: str
    destination_address: str
    reference_route_file: Path
    timezone: str
    sample_times: tuple[str, ...]
    email_from_time: str
    forecast_target_time: str
    max_sample_lateness_seconds: int
    gradient_moderate_threshold: float
    gradient_fast_threshold: float
    gradient_extreme_threshold: float
    smtp_host: str
    smtp_port: int
    smtp_username: str
    smtp_password: str
    smtp_from: str
    email_to: tuple[str, ...]
    smtp_starttls: bool
    dry_run: bool

    @classmethod
    def from_env(cls) -> "Settings":
        sample_times = tuple(
            x.strip() for x in os.getenv(
                "SAMPLE_TIMES", "06:30,06:40,06:50,07:00,07:10,07:20,07:30"
            ).split(",") if x.strip()
        )
        email_to = tuple(
            x.strip() for x in os.getenv("EMAIL_TO", "javier.garrido.pino@gmail.com").split(",") if x.strip()
        )
        settings = cls(
            tomtom_api_key=os.getenv("TOMTOM_API_KEY", "").strip(),
            origin_address=os.getenv(
                "ORIGIN_ADDRESS",
                "Calle Zaragoza, 11, 28223 Pozuelo de Alarcón, Madrid, España",
            ).strip(),
            destination_address=os.getenv(
                "DESTINATION_ADDRESS", "Calle Xaudaró, 25, Madrid, España"
            ).strip(),
            reference_route_file=Path(os.getenv("REFERENCE_ROUTE_FILE", "state/reference_route.json")),
            timezone=os.getenv("TIMEZONE", "Europe/Madrid"),
            sample_times=sample_times,
            email_from_time=os.getenv("EMAIL_FROM_TIME", "06:50"),
            forecast_target_time=os.getenv("FORECAST_TARGET_TIME", "07:00"),
            max_sample_lateness_seconds=_int("MAX_SAMPLE_LATENESS_SECONDS", 180),
            gradient_moderate_threshold=_float("GRADIENT_MODERATE_THRESHOLD", 0.5),
            gradient_fast_threshold=_float("GRADIENT_FAST_THRESHOLD", 1.5),
            gradient_extreme_threshold=_float("GRADIENT_EXTREME_THRESHOLD", 3.0),
            smtp_host=os.getenv("SMTP_HOST", "smtp.gmail.com").strip(),
            smtp_port=_int("SMTP_PORT", 465),
            smtp_username=os.getenv("SMTP_USERNAME", "javier.garrido.pino@gmail.com").strip(),
            smtp_password=os.getenv("SMTP_PASSWORD", "").strip(),
            smtp_from=os.getenv("SMTP_FROM", "javier.garrido.pino@gmail.com").strip(),
            email_to=email_to,
            smtp_starttls=_bool("SMTP_STARTTLS", False),
            dry_run=_bool("DRY_RUN", False),
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        if not self.tomtom_api_key:
            raise ValueError("Falta TOMTOM_API_KEY")
        if not self.sample_times:
            raise ValueError("SAMPLE_TIMES no puede estar vacío")
        if self.email_from_time not in self.sample_times:
            raise ValueError("EMAIL_FROM_TIME debe ser una de SAMPLE_TIMES")
        if self.forecast_target_time not in self.sample_times:
            raise ValueError("FORECAST_TARGET_TIME debe ser una de SAMPLE_TIMES")
        if not self.dry_run:
            missing = []
            for name, value in [
                ("SMTP_HOST", self.smtp_host),
                ("SMTP_USERNAME", self.smtp_username),
                ("SMTP_PASSWORD", self.smtp_password),
                ("SMTP_FROM", self.smtp_from),
                ("EMAIL_TO", self.email_to),
            ]:
                if not value:
                    missing.append(name)
            if missing:
                raise ValueError(f"Faltan variables de email: {', '.join(missing)}")
