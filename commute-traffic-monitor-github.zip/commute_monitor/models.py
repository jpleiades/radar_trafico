from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class TrafficSample:
    scheduled_time: str
    observed_at: datetime
    duration_seconds: int
    traffic_delay_seconds: int | None
    no_traffic_seconds: int | None
    historic_traffic_seconds: int | None
    live_traffic_seconds: int | None
    distance_meters: int | None

    @property
    def duration_minutes(self) -> float:
        return self.duration_seconds / 60.0

    @property
    def delay_minutes(self) -> float | None:
        if self.traffic_delay_seconds is None:
            return None
        return self.traffic_delay_seconds / 60.0

    def to_dict(self) -> dict:
        data = asdict(self)
        data["observed_at"] = self.observed_at.isoformat()
        data["duration_minutes"] = round(self.duration_minutes, 2)
        data["delay_minutes"] = None if self.delay_minutes is None else round(self.delay_minutes, 2)
        return data
