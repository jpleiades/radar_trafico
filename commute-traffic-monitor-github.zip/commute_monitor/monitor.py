from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from .analytics import forecast_for_target, gradient, hhmm_to_minutes
from .config import Settings
from .emailer import build_email, send_email
from .models import TrafficSample
from .storage import save_samples
from .tomtom import TomTomClient

LOG = logging.getLogger("commute_monitor")


def _scheduled_datetime(now: datetime, hhmm: str) -> datetime:
    hour, minute = [int(x) for x in hhmm.split(":", 1)]
    return now.replace(hour=hour, minute=minute, second=0, microsecond=0)


def _sleep_until(target: datetime) -> None:
    while True:
        remaining = (target - datetime.now(target.tzinfo)).total_seconds()
        if remaining <= 0:
            return
        time.sleep(min(remaining, 30))


def _should_email(settings: Settings, scheduled_time: str) -> bool:
    return hhmm_to_minutes(scheduled_time) >= hhmm_to_minutes(settings.email_from_time)


def _analyze_and_email(settings: Settings, samples: list[TrafficSample]) -> None:
    forecast = forecast_for_target(samples, settings.forecast_target_time)
    trend = gradient(
        samples,
        settings.gradient_moderate_threshold,
        settings.gradient_fast_threshold,
        settings.gradient_extreme_threshold,
    )
    message = build_email(settings, samples, forecast, trend)
    send_email(settings, message)
    LOG.info(
        "Email: previsión %s %.1f min; gradiente=%s (%+.2f min/10m)",
        forecast.target_time,
        forecast.estimated_minutes,
        trend.label,
        trend.slope_minutes_per_10,
    )


def run_morning(settings: Settings) -> None:
    tz = ZoneInfo(settings.timezone)
    client = TomTomClient(settings.tomtom_api_key)
    reference = client.load_reference(settings.reference_route_file)
    samples: list[TrafficSample] = []
    today = datetime.now(tz)
    date_str = today.date().isoformat()

    LOG.info("Monitorizando %s → %s", settings.origin_address, settings.destination_address)
    LOG.info("Ruta fija cargada: %s", settings.reference_route_file)

    for scheduled_time in settings.sample_times:
        target = _scheduled_datetime(today, scheduled_time)
        now = datetime.now(tz)
        lateness = (now - target).total_seconds()

        if lateness < 0:
            LOG.info("Esperando cata de las %s", scheduled_time)
            _sleep_until(target)
        elif lateness > settings.max_sample_lateness_seconds:
            LOG.warning("Cata %s omitida: job llegó %.0f s tarde", scheduled_time, lateness)
            continue
        else:
            LOG.warning("Cata %s tomada con %.0f s de retraso", scheduled_time, max(lateness, 0))

        observed_at = datetime.now(tz)
        try:
            sample = client.measure_reference_route(reference, scheduled_time, observed_at)
        except Exception:
            LOG.exception("Falló la cata de las %s; continúo con la siguiente", scheduled_time)
            continue

        samples.append(sample)
        save_samples(samples, Path("output"), date_str)
        LOG.info(
            "Cata %s: %.1f min, retraso tráfico=%s",
            scheduled_time,
            sample.duration_minutes,
            "—" if sample.delay_minutes is None else f"{sample.delay_minutes:.1f} min",
        )

        if _should_email(settings, scheduled_time):
            try:
                _analyze_and_email(settings, samples)
            except Exception:
                LOG.exception("No se pudo enviar el correo de las %s", scheduled_time)


def run_once(settings: Settings, send: bool = False) -> TrafficSample:
    tz = ZoneInfo(settings.timezone)
    now = datetime.now(tz)
    client = TomTomClient(settings.tomtom_api_key)
    reference = client.load_reference(settings.reference_route_file)
    sample = client.measure_reference_route(reference, now.strftime("%H:%M"), now)
    LOG.info("Medición instantánea: %.1f min", sample.duration_minutes)
    if send:
        _analyze_and_email(settings, [sample])
    return sample
