from __future__ import annotations

from .config import Settings
from .tomtom import TomTomClient


def main() -> None:
    settings = Settings.from_env()
    client = TomTomClient(settings.tomtom_api_key)
    print("Geocodificando origen y destino y fijando la ruta de referencia...")
    reference = client.build_reference_route(settings.origin_address, settings.destination_address)
    client.save_reference(reference, settings.reference_route_file)
    km = (reference.distance_meters or 0) / 1000
    print(f"Ruta guardada en {settings.reference_route_file} ({km:.1f} km).")
    print("Haz commit de este fichero en GitHub para medir exactamente el mismo trazado cada mañana.")


if __name__ == "__main__":
    main()
