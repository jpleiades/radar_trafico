from __future__ import annotations

import csv
import json
from pathlib import Path

from .models import TrafficSample


CSV_FIELDS = [
    "scheduled_time",
    "observed_at",
    "duration_seconds",
    "duration_minutes",
    "traffic_delay_seconds",
    "delay_minutes",
    "no_traffic_seconds",
    "historic_traffic_seconds",
    "live_traffic_seconds",
    "distance_meters",
]


def save_samples(samples: list[TrafficSample], output_dir: Path, date_str: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / f"{date_str}.csv"
    json_path = output_dir / f"{date_str}.json"

    rows = [s.to_dict() for s in samples]
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    json_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
