from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests

from .models import TrafficSample


@dataclass(frozen=True)
class Coordinate:
    lat: float
    lon: float

    def as_path(self) -> str:
        return f"{self.lat:.7f},{self.lon:.7f}"


@dataclass(frozen=True)
class ReferenceRoute:
    origin_address: str
    destination_address: str
    origin: Coordinate
    destination: Coordinate
    encoded_polyline: str
    encoded_polyline_precision: int
    distance_meters: int | None
    created_at: str

    def to_dict(self) -> dict:
        return {
            "origin_address": self.origin_address,
            "destination_address": self.destination_address,
            "origin": {"lat": self.origin.lat, "lon": self.origin.lon},
            "destination": {"lat": self.destination.lat, "lon": self.destination.lon},
            "encoded_polyline": self.encoded_polyline,
            "encoded_polyline_precision": self.encoded_polyline_precision,
            "distance_meters": self.distance_meters,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ReferenceRoute":
        return cls(
            origin_address=data["origin_address"],
            destination_address=data["destination_address"],
            origin=Coordinate(**data["origin"]),
            destination=Coordinate(**data["destination"]),
            encoded_polyline=data["encoded_polyline"],
            encoded_polyline_precision=int(data["encoded_polyline_precision"]),
            distance_meters=data.get("distance_meters"),
            created_at=data["created_at"],
        )


class TomTomClient:
    def __init__(self, api_key: str, timeout_seconds: int = 25):
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.session = requests.Session()

    def geocode(self, address: str) -> Coordinate:
        url = f"https://api.tomtom.com/search/2/geocode/{quote(address, safe='')}.json"
        response = self.session.get(
            url,
            params={"key": self.api_key, "limit": 1, "countrySet": "ES", "language": "es-ES"},
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        payload = response.json()
        results = payload.get("results") or []
        if not results:
            raise RuntimeError(f"TomTom no pudo geocodificar: {address}")
        pos = results[0]["position"]
        return Coordinate(lat=float(pos["lat"]), lon=float(pos["lon"]))

    def build_reference_route(self, origin_address: str, destination_address: str) -> ReferenceRoute:
        origin = self.geocode(origin_address)
        destination = self.geocode(destination_address)
        url = self._route_url(origin, destination)
        params = {
            "key": self.api_key,
            "travelMode": "car",
            "routeType": "fastest",
            "traffic": "true",
            "departAt": "now",
            "maxAlternatives": 0,
            "routeRepresentation": "encodedPolyline",
            "coordinatePrecision": "full",
            "computeTravelTimeFor": "all",
        }
        response = self.session.get(url, params=params, timeout=self.timeout_seconds)
        response.raise_for_status()
        payload = response.json()
        route = self._first_route(payload)
        polyline = route.get("encodedPolyline")
        precision = route.get("encodedPolylinePrecision")
        if not polyline or precision is None:
            raise RuntimeError("TomTom no devolvió la polilínea de referencia")
        summary = route.get("summary", {})
        return ReferenceRoute(
            origin_address=origin_address,
            destination_address=destination_address,
            origin=origin,
            destination=destination,
            encoded_polyline=polyline,
            encoded_polyline_precision=int(precision),
            distance_meters=summary.get("lengthInMeters"),
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    def measure_reference_route(
        self,
        reference: ReferenceRoute,
        scheduled_time: str,
        observed_at: datetime,
    ) -> TrafficSample:
        url = self._route_url(reference.origin, reference.destination)
        params = {
            "key": self.api_key,
            "travelMode": "car",
            "traffic": "true",
            "departAt": "now",
            "maxAlternatives": 0,
            "routeRepresentation": "summaryOnly",
            "computeTravelTimeFor": "all",
            # Strict is explicitly intended for reconstructing a route previously
            # obtained from TomTom, keeping the geometry as close as possible.
            "reconstructionMode": "strict",
        }
        body = {
            "encodedPolyline": reference.encoded_polyline,
            "encodedPolylinePrecision": reference.encoded_polyline_precision,
        }
        response = self.session.post(
            url,
            params=params,
            json=body,
            timeout=self.timeout_seconds,
        )
        if not response.ok:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(f"Error TomTom {response.status_code}: {detail}")
        route = self._first_route(response.json())
        summary = route.get("summary") or {}
        if "travelTimeInSeconds" not in summary:
            raise RuntimeError("Respuesta TomTom sin travelTimeInSeconds")
        return TrafficSample(
            scheduled_time=scheduled_time,
            observed_at=observed_at,
            duration_seconds=int(summary["travelTimeInSeconds"]),
            traffic_delay_seconds=_optional_int(summary.get("trafficDelayInSeconds")),
            no_traffic_seconds=_optional_int(summary.get("noTrafficTravelTimeInSeconds")),
            historic_traffic_seconds=_optional_int(summary.get("historicTrafficTravelTimeInSeconds")),
            live_traffic_seconds=_optional_int(summary.get("liveTrafficIncidentsTravelTimeInSeconds")),
            distance_meters=_optional_int(summary.get("lengthInMeters")),
        )

    @staticmethod
    def save_reference(reference: ReferenceRoute, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(reference.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def load_reference(path: Path) -> ReferenceRoute:
        if not path.exists():
            raise FileNotFoundError(
                f"No existe {path}. Ejecuta primero: python -m commute_monitor.reference_route"
            )
        return ReferenceRoute.from_dict(json.loads(path.read_text(encoding="utf-8")))

    @staticmethod
    def _first_route(payload: dict) -> dict:
        routes = payload.get("routes") or []
        if not routes:
            raise RuntimeError(f"TomTom no devolvió rutas: {payload}")
        return routes[0]

    @staticmethod
    def _route_url(origin: Coordinate, destination: Coordinate) -> str:
        return (
            "https://api.tomtom.com/routing/1/calculateRoute/"
            f"{origin.as_path()}:{destination.as_path()}/json"
        )


def _optional_int(value):
    return None if value is None else int(value)
