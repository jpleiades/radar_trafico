from datetime import datetime, timezone

from commute_monitor.analytics import forecast_for_target, gradient
from commute_monitor.models import TrafficSample


def s(hhmm: str, mins: float) -> TrafficSample:
    return TrafficSample(
        scheduled_time=hhmm,
        observed_at=datetime.now(timezone.utc),
        duration_seconds=int(mins * 60),
        traffic_delay_seconds=0,
        no_traffic_seconds=None,
        historic_traffic_seconds=None,
        live_traffic_seconds=None,
        distance_meters=10000,
    )


def test_forecast_at_0650_projects_0700():
    samples = [s("06:30", 20), s("06:40", 22), s("06:50", 24)]
    result = forecast_for_target(samples, "07:00")
    assert round(result.estimated_minutes, 1) == 26.0


def test_forecast_uses_actual_0700_after_target():
    samples = [s("06:30", 20), s("06:40", 22), s("06:50", 24), s("07:00", 27), s("07:10", 31)]
    result = forecast_for_target(samples, "07:00")
    assert round(result.estimated_minutes, 1) == 27.0
    assert "observado" in result.method


def test_gradient_categories():
    assert gradient([s("06:30", 20), s("06:40", 20.3)], 0.5, 1.5, 3.0).label == "estable"
    assert gradient([s("06:30", 20), s("06:40", 21)], 0.5, 1.5, 3.0).label == "creciente moderado"
    assert gradient([s("06:30", 20), s("06:40", 22)], 0.5, 1.5, 3.0).label == "creciente rápido"
    assert gradient([s("06:30", 20), s("06:40", 24)], 0.5, 1.5, 3.0).label == "creciente extremo"
