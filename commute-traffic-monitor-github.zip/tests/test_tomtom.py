from commute_monitor.tomtom import Coordinate, TomTomClient


class FakeResponse:
    def __init__(self, payload, ok=True, status_code=200):
        self._payload = payload
        self.ok = ok
        self.status_code = status_code
        self.text = ''

    def raise_for_status(self):
        if not self.ok:
            raise RuntimeError(self.status_code)

    def json(self):
        return self._payload


def test_build_reference_route_reads_encoded_polyline_from_leg(monkeypatch):
    client = TomTomClient('x')
    coords = [Coordinate(40.4, -3.8), Coordinate(40.5, -3.7)]
    monkeypatch.setattr(client, 'geocode', lambda _: coords.pop(0))
    payload = {
        'routes': [{
            'summary': {'lengthInMeters': 12345},
            'legs': [{
                'summary': {},
                'encodedPolyline': 'abc123',
                'encodedPolylinePrecision': 7,
            }],
        }]
    }
    monkeypatch.setattr(client.session, 'get', lambda *a, **k: FakeResponse(payload))
    ref = client.build_reference_route('origen', 'destino')
    assert ref.encoded_polyline == 'abc123'
    assert ref.encoded_polyline_precision == 7
    assert ref.distance_meters == 12345
